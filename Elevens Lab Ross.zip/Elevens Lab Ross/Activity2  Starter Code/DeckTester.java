/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		String[] s = {"Heart","Spade","Heart"};
		String[] r = {"A", "K", "J"};
		int[] i = {1,0,0};
		Deck deck = new Deck(r,s,i);
		System.out.println(deck.isEmpty());
		System.out.println(deck.size());
		System.out.println(deck.deal());
		System.out.println(deck.size());
	}
}
